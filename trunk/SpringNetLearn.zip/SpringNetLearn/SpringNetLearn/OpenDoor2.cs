﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SpringNetLearn
{
    public class OpenDoor2
    {
        public void WalkInto(string arg)
        {
            Console.WriteLine(arg + "开了，李四进去了");
        }
    }
}
